package net.mcreator.tensurareimagined.procedures;

public class MagiculeStartProcedure {
	public static void execute() {
	}
}
